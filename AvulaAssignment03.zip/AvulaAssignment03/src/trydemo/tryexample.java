package trydemo;

public class tryexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      try {
	          System.out.println("Try Block");
	       } finally {
	          System.out.println("Finally Block");
	       }

	}

}
