package faildemo;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class FailSafeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    Map<Integer, String> map = new ConcurrentHashMap<>();
        map.put(1, "one");
        map.put(2, "two");
        map.put(3, "three");

        // Create an iterator for the ConcurrentHashMap
        Iterator<Map.Entry<Integer, String>> iterator = map.entrySet().iterator();

        // Modify the ConcurrentHashMap while iterating
        while (iterator.hasNext()) {
            Map.Entry<Integer, String> entry = iterator.next();
            System.out.println(entry.getKey() + ": " + entry.getValue());
            if (entry.getKey() == 2) {
                // Concurrent modification: Remove an element while iterating
                map.remove(3);
            }
        }

	}

}
