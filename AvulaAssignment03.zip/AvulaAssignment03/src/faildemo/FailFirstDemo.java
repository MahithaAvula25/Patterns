package faildemo;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;

public class FailFirstDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  List<Integer> numbers = new ArrayList<>();
	        numbers.add(1);
	        numbers.add(2);
	        numbers.add(3);

	        // Create an iterator for the list
	        Iterator<Integer> iterator = numbers.iterator();

	        // Modify the list while iterating
	        try {
	            while (iterator.hasNext()) {
	                Integer number = iterator.next();
	                System.out.println(number);
	                if (number == 2) {
	                    // Concurrent modification: Add an element while iterating
	                    numbers.add(4);
	                    
	                }
	                
	            }

	        } catch (ConcurrentModificationException e) {
	            System.out.println("ConcurrentModificationException caught: " + e.getMessage());
	        }
	}

}
