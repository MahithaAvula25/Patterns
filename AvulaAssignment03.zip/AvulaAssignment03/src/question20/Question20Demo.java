package question20;

public class Question20Demo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		MyThread temp = new MyThread();
		Thread thr = new Thread(temp);
		System.out.println("thread state: " + thr.getState());//new
		thr.start();
		//runnable
		System.out.println("thread sstate before main sleep : " +thr.getState());
		Thread.sleep(1000);
		System.out.println("thread(thr) state after sleep : " +thr.getState());//TIMED_WAITING
		Thread.sleep(2000);
		System.out.println("thread(thr) state after 2  sleep : " +thr.getState());//terminated
	}

}
class MyThread implements Runnable{
	   public void run() {
		   try {
			   Thread.sleep(2500);
			   System.out.println("tthread(thr) in run(), state: " + Thread.currentThread().getState());
			   
		   }catch(InterruptedException e) {
			   e.printStackTrace();
		   }
	   }
}