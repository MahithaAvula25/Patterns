package threadtypes;
import java.util.*;
public class ThreadExampleOnedriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadExampleOne t1 = new ThreadExampleOne();
		t1.start();
	}

}
