package threadtypes;

public class ThreadExampleTwo implements Runnable{
	 public ThreadExampleTwo(){
	        
	    }
	    public void run() {
	    	System.out.println("thread started.");
	    }
}
