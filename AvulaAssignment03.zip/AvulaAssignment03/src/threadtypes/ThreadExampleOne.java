package threadtypes;

public class ThreadExampleOne extends Thread {
	public void run(){
		System.out.println("thread started.");
	}
}
