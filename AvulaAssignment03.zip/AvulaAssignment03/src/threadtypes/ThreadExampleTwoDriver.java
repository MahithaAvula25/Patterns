package threadtypes;

public class ThreadExampleTwoDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Starting Main Thread");
        ThreadExampleTwo ex2 = new ThreadExampleTwo();

         Thread t = new Thread(ex2);
         t.start();
         System.out.println("End of Main Thread");
	}

}
