package serilizationdemo;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class DriverStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
		 Student emp1 =new Student(25,"Nik");
		 Student emp2 =new Student(30,"Harry");
         FileOutputStream fout=new FileOutputStream("output.txt");
         ObjectOutputStream out=new ObjectOutputStream(fout);
         out.writeObject(emp1);
         out.writeObject(emp2);
         out.flush();
         out.close();
         System.out.println("Successfully");
		}
  catch(Exception e){
         System.out.println(e);
         }
	}
}


