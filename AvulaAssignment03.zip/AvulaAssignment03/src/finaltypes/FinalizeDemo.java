package finaltypes;

public class FinalizeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinalizeDemo str = new FinalizeDemo();
		str = null;
		System.gc();
		System.out.println("In main method");
	}	
	protected void finalize() {
		System.out.println("In finalize method");
	}
	}


