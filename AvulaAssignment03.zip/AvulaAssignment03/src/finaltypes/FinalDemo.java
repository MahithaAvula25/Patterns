package finaltypes;

public class FinalDemo {
	public final int age = 23;  
    public void display()
   {  
    System.out.println("Age:  "+age);
    }  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 FinalDemo f = new FinalDemo();    
		    f.display();  

	}

}
