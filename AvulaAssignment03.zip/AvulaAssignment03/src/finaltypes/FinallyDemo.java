package finaltypes;

public class FinallyDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {    
	        System.out.println("Inside try block");  
	        int data=25/5;    
	        System.out.println(data);    
	      }   
	    catch (ArithmeticException e){  
	        System.out.println("Arithmetic Exception occurred "+ e);   
	      }     
	    finally {  
	        System.out.println("Inside finally block");  
	      }
	}

}
