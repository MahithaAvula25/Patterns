package stringbufferandbuilder;

public class StringBuilderDemo
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder str = new StringBuilder("Example ");
		str.append("to ");
		System.out.println(str);
		str.append("StringBuilder");
		System.out.println(str);

	}

}
