package stringbufferandbuilder;

public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer str=new StringBuffer("Mahitha"); 
System.out.println(str.toString());
//updating the string
str.append(" example to StringBuffer");
System.out.println(str.toString());

	}

}
