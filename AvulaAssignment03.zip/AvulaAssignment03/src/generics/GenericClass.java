package generics;

public class GenericClass<T> {
	private T name;
	public T getName() {
		return name;
	}
	public void setName(T name) {
		this.name = name;
		
	}
	

	@Override
	public String toString() {
		return "Name : " + name;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenericClass temp = new GenericClass();
		temp.setName("Mahitha Avula");
		System.out.println(temp);

	}

}
