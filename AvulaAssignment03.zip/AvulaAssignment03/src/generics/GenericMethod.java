package generics;

public class GenericMethod {
	public static<T>void trailMethod(T[]input){
		for(T am:input) {
			System.out.println(am);
		}
		System.out.println();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String []array= {"joy","jim"};
		trailMethod(array);

	}

}
