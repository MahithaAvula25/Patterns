package java8demo;

public class DefaultDemoDriver implements DefaultDemo{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 DefaultDemoDriver dem = new DefaultDemoDriver();  
		 dem.say();   // calling the default method  
		 dem.sayMore("Driver class demo");  // calling the abstract method  from superclass
	}

	@Override
	public void sayMore(String msg) {
		System.out.println(msg); 
	}

}
