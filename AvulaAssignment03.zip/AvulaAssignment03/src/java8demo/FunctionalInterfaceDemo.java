package java8demo;

public interface FunctionalInterfaceDemo {
	public void demo(String msg);
}
