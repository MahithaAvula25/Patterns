package java8demo;

public interface LamdaDemo {
	public void display();
}
