package java8demo;

public class javastreamDemo {
	 String name;  
	    float price;  
	    public javastreamDemo(String name, float price) {   
	        this.name = name;  
	        this.price = price;  
	    }
}
