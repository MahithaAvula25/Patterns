package java8demo;

public interface DefaultDemo {
	public default void say(){  
        System.out.println("Example for default method");  
    } 
    public void sayMore(String msg);
}
