package java8demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class javaDemoDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<javastreamDemo> productsList = new ArrayList<javastreamDemo>();  
        //Adding Products  
        productsList.add(new javastreamDemo("Macbook",25000f));  
        productsList.add(new javastreamDemo("Dell",30000f));  
        List<Float> productPriceList2 =productsList.stream()  
                                     .filter(p -> p.price > 10000)// filtering data  
                                     .map(p->p.price)        // fetching price  
                                     .collect(Collectors.toList()); // collecting as list  
        System.out.println(productPriceList2);
	}

}
