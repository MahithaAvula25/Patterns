package java8demo;

public class FunctionalnterfaceDemoDriver implements FunctionalInterfaceDemo{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FunctionalnterfaceDemoDriver temp = new FunctionalnterfaceDemoDriver();  
        temp.demo("Example for functional interface");
	}

	@Override
	public void demo(String msg) {
		// TODO Auto-generated method stub
		 System.out.println(msg);  
	}

}
