package java8demo;

public class LamdaDemoDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int age=23;  
	        
	        //with lambda  
	        LamdaDemo l1=()->{  
	            System.out.println("Age is "+age);  
	        };  
	        l1.display();
	}

}
