package java8demo;

import java.util.ArrayList;
import java.util.List;

public class ForEachDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 List<String> list = new ArrayList<String>();  
		 list.add("Teddy");  
		 list.add("Bear");  
		 list.add("Panda");  
		 list.add("Lion");  
	        System.out.println("forEach Method demo :"+list);  
	        list.forEach(listtemp -> System.out.println(listtemp));
	}

}
