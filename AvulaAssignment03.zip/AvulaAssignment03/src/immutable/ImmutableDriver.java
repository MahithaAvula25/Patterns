package immutable;

public class ImmutableDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ImmutableDemo obj = new ImmutableDemo("Mahitha", 23);

	    System.out.println("Name: " + obj.getName());
	    System.out.println("Age: " + obj.getAge());


	}

}
