package singletonquestion27demo;

public class Question27Demo {
	 private static Question27Demo instance = null;

	   private Question27Demo() {}

	   public static synchronized Question27Demo getInstance() {
	       if (instance == null) {
	           instance = new Question27Demo();
	       }

	       return instance;

	   }
}
