package throwcaluse;

public class exampleTwo extends exampleOne {
	public void test() {
        System.out.println("Subclass");
        }

}
