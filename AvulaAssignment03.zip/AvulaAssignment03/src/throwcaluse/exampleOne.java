package throwcaluse;

import java.io.FileNotFoundException;

public  abstract class exampleOne {
    public void test()throws FileNotFoundException{
    System.out.println("EXAMPLE IN SUPERCLASS");
    }


}
