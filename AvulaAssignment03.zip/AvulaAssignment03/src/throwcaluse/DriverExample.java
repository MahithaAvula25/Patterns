package throwcaluse;

public class DriverExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		exampleTwo e = new exampleTwo();
        e.test();

	}

}
