package stringclsandstrbuffer;

public class strBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        StringBuffer sb= new StringBuffer("Mahitha");
        System.out.println(sb.toString());
        sb.reverse();
        System.out.println(sb.toString());
        sb.append("avula");
       System.out.println(sb.toString());


	}

}
	