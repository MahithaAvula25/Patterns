package stringclsandstrbuffer;

public class stringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  String str1 = "Mahitha";
	      String name = str1.toUpperCase();
	      System.out.println(name);
	      String add = str1.concat("Avula");
	      System.out.println(add);

	}

}
