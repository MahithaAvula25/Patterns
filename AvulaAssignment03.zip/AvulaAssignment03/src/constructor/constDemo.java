package constructor;

public class constDemo {
	public final String name;
	public final int age;
	public final constDemo() {
		this.name = "MahithaAvula";
		this.age = 23;
	}
	
	public void display() {
	    System.out.println("Name "+this.name );
	    System.out.println("Age : "+this.age );
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new constDemo().display();

	}

}
