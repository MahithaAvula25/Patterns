package arraylistandvector;

import java.util.Enumeration;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector ve = new Vector(); 	 
		//Adding elements to vector
		ve.addElement("MAHITHA"); 
		ve.addElement("AVULA");
		// Traversing vector elements
		System.out.println("vector:"+ve); 
		Enumeration enm = ve.elements(); 
		while (enm.hasMoreElements()) { 
			System.out.println(enm.nextElement());

	}
	}
}


