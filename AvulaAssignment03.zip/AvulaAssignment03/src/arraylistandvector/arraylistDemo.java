package arraylistandvector;

import java.util.ArrayList;

import java.util.Iterator;
public class arraylistDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList ar = new ArrayList();  
		ar.add("MAHITHA");
		ar.add("AVULA"); 
       
		// Traversing ArrayList elements
		System.out.println("arraylist:"+ar); 
		Iterator itr = ar.iterator(); 
		while (itr.hasNext()) 
			System.out.println(itr.next()); 

	}

}
