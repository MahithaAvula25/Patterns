package arraylistsync;

import java.util.concurrent.CopyOnWriteArrayList;

import java.util.Iterator;

public class CopyOnWriteDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<String>();
		list.add("Mahitha");
		list.add("Avula");
		
    System.out.println("Elements of synchronized ArrayList :"+list);

    Iterator<String> itr = list.iterator();
    while (itr.hasNext())
        System.out.println(itr.next());

	}

}
