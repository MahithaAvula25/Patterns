package arraylistsync;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class CollectionsyncDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add("Mahitha");
		list.add("Avula");
		list.add("Teddy");
		list.add("Bear");
		
		list = Collections.synchronizedList(list);
		synchronized(list) {
			Iterator<String> itr = list.listIterator();
			while(itr.hasNext()) {
				System.out.println(itr.next());


	}


}
	}
}