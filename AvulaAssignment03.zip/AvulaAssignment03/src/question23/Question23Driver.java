package question23;

public class Question23Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "Mahitha";
		name.concat("Avula");
		System.out.println("Main : " +name);
		Thread temp = new Thread(new Runnable() {
			public void run() {
				name.concat("temp");
				System.out.println("Thread1: " +name);
				
			}

		});
		Thread t1 = new Thread(new Runnable() {
			public void run() {
				name.concat("t1");
				System.out.println("Thread2 : " +name);
				
			}
			
		});
		temp.start();
		t1.start();



	}

}
