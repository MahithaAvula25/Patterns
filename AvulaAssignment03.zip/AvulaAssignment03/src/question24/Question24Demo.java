package question24;

public class Question24Demo {
	protected void finalize() throws Throwable{
		System.out.println("Finalize called,hence garbage collector triggered");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Question24Demo temp = new Question24Demo();
		System.out.println("Calling garbage collector before making null");
		System.gc();
		temp = null;
		System.out.println("Calling garbage collector after making null");
		System.gc();
	}

}
