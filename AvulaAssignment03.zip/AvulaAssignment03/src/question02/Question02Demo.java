package question02;

public class Question02Demo {
public void PublicDemo() {
	
}
public void PrivateDemo() {
	
}
void DefaultMethodDemo() {
	
}
protected void ProtectedDemo() {
	
}
}
