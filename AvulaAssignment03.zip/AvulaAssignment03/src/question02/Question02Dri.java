package question02;

public class Question02Dri extends Question02Demo{
	void PublicDemo() {
		//in public we cant change and we get an error
	}
	protected void DefaultMethodDemo() {
		
	}
	protected void ProtectedDemo() {
		

		}
}
