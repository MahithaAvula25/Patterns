package covariant;

public class Animal {
	public Animal getInfo() {
		System.out.println("Animals description");
		return this;
	}
	

}
