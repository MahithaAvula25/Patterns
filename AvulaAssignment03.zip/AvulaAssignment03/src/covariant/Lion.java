package covariant;

public class Lion extends Animal{
public Lion getInfo() {
	System.out.println("Lion subclass");
	return this;
	
}
public void sound() {
	System.out.println("Lion roars");
}
}
