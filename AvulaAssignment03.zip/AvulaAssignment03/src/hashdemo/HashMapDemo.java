package hashdemo;

import java.util.HashMap;
import java.util.Map;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,String> temp = new HashMap<String,String>();
		temp.put("Maryville", "MO");
		temp.put("Kansas", "KS");
		temp.put("Florida", "FL");
		
		temp.put("Atlanta", null);
		temp.put(null, null);
		temp.put(null, "India");
		
		System.out.println("Elements in Hashtable are:\n " + temp.entrySet());
		System.out.println(temp.get("Florida"));
		System.out.println(temp.get("Atlanta"));

	}

}
