package hashdemo;

import java.util.Hashtable;
import java.util.Map;

public class HahhtableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,String> temp = new Hashtable<String,String>();
		temp.put("Maryville", "MO");
		temp.put("Kansas", "KS");
		temp.put("Florida", "FL");
		
		
		System.out.println("Elements in Hashtable are:\n " + temp.entrySet());
		System.out.println(temp.get("Kansas"));


	}

}
