package singleton;

public class Question26Demo {
	private static volatile Question26Demo obj = null;
	private Question26Demo() {
		
	}
	public static Question26Demo getInstance() {
		if(obj==null) {
			synchronized (Question26Demo.class) {
				if(obj==null) {
					obj = new Question26Demo();
				}
				
			}
		}
		return obj;
	}
}

